from pathlib import Path
import subprocess,sys
p=Path.cwd(); w=Path('/tmp/midilooper-boot-red-verified'); w.mkdir(exist_ok=False)
subprocess.run([sys.executable,str(p/'tools/midilooper-reader/prepare_native_decode_headers.py'),str(w/'headers')],check=True)
(w/'BootRecoveryBefore.cpp').write_bytes(subprocess.check_output(['git','show','HEAD:src/StorageManager/BootRecovery.cpp']))
t=w/'tests/test_offline_boot_recovery'; t.mkdir(parents=True)
s=(p/'test/test_offline_boot_recovery/test_offline_boot_recovery.cpp').read_text()
s=s.replace('"../test_offline_undo_recovery/test_offline_undo_recovery.cpp"','"'+str(p/'test/test_offline_undo_recovery/test_offline_undo_recovery.cpp')+'"')
s=s.replace('"../../src/BootRecoveryPolicy.cpp"','"'+str(p/'src/BootRecoveryPolicy.cpp')+'"').replace('"../../src/SetBrowserOverlayPolicy.cpp"','"'+str(p/'src/SetBrowserOverlayPolicy.cpp')+'"')
s=s.replace('"../../src/StorageManager/BootRecovery.cpp"','"'+str(w/'BootRecoveryBefore.cpp')+'"')
s=s[:s.index('int main() {')]+'''int main() { UNITY_BEGIN(); RUN_TEST(test_reconstructed_workspace_loads); return UNITY_END(); }\n'''
(t/'test.cpp').write_text(s)
(w/'link.py').write_text("Import('env')\nenv.Append(LINKFLAGS=['-Wl,-dead_strip'])\n")
(w/'platformio.ini').write_text(f'''[platformio]
include_dir = {w/'headers'}
test_dir = {w/'tests'}
build_dir = {w/'build'}
[env:native]
platform = native
test_framework = unity
build_flags = -std=gnu++17 -DPIO_UNIT_TEST_NATIVE=1 -DRECOVERY_TEENSY_ABI=1 -I{w/'headers/EditStates'} -I{p/'test/test_support/firmware'} -ffunction-sections -fdata-sections
extra_scripts = pre:{w/'link.py'}
''')
